﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula0205
{
    /*
     
    1) Crie uma classe Carro com três propriedades: Marca, Modelo e Ano. Use o encapsulamento adequado para garantir que:
       a) A Marca e o Modelo possam ser lidos e escritos externamente.
       b) O Ano só possa ser definido no construtor e acessado (mas não modificado) depois disso.

     */
    internal class Carro
    {
        private string _marca;
        private string _modelo;
        private int _ano;

        public Carro()
        {
            _ano = 2025;
        }

        public int Ano
        {
            get { return _ano; }
        }

        public string Marca
        {
            get
            { return _marca; }
            set
            {

                if (string.IsNullOrEmpty(value))
                {
                    throw new Exception("Nome não pode ser vazio!");
                }
                {
                    _marca = value;
                }

            }
        }

        public string Modelo
        {
            get
            { return _modelo; }
            set
            {

                if (string.IsNullOrEmpty(value))
                {
                    throw new Exception("Nome não pode ser vazio!");
                }
                {
                    _modelo = value;
                }

            }
        }


    }

}
