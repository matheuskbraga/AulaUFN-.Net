﻿namespace Aula0205
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // instanciar o objeto da classe
            Pessoa p = new Pessoa();
            Produto produto = new Produto();
            Carro carro = new Carro();

            try
            {
                p.Nome = "Matheus Braga"; // chamando o setter da propriedade
                p.Idade = 22;
                produto.Nome = "Computador";
                produto.Preco = 4000;
                produto.Imposto = 400;
                carro.Marca = "Ford";
                carro.Modelo = "Fiesta";

            }
            catch (Exception ex)
            {

                Console.WriteLine("Erro, algum campo não está certo!\n" + ex.Message);
            }

            Console.WriteLine("Nome da pessoa: " + p.Nome); // chamando o getter da propriedade
            Console.WriteLine("Idade da pessoa: " + p.Idade);
            Console.WriteLine("Nome do produto: " + produto.Nome);
            Console.WriteLine("Preço do produto: " + produto.Preco);
            Console.WriteLine("Imposto do produto: " + produto.Imposto);
            Console.WriteLine("Valor final: " + produto.PrecoFinal);
            Console.WriteLine("Marca do carro do user: " + carro.Marca);
            Console.WriteLine("Modelo do carro do user: " + carro.Ano);
        }
    }
}