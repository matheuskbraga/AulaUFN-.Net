using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace UFNCC_DotNetASPTeste.Pages.Usuarios
{
    public class EditarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
